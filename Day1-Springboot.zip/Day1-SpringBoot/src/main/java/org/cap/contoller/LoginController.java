package org.cap.contoller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@RequestMapping(value = "/validateUser",method = RequestMethod.POST)
	public String validateUSerLogin(@RequestParam("userName")String userName,
			@RequestParam("userPwd") String userPwd) {
		
		if(userName.equals("tom") && userPwd.equals("tom12"))
			return "success";
		else
			return "redirect:/";
	}
	
}
