package org.cap.model;

import java.time.LocalDate;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;





@JacksonXmlRootElement(localName = "ProductDetails")
public class Product {
	
	@JacksonXmlProperty(isAttribute = true)
	private int productId;
	private String productName;
	private LocalDate expiryDate;
	private int quantity;
	private double price;
	private Supplier supplier;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public Product(int productId, String productName, LocalDate expiryDate, int quantity, double price,
			Supplier supplier) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.price = price;
		this.supplier = supplier;
	}
	public Product() {
		super();
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", expiryDate=" + expiryDate
				+ ", quantity=" + quantity + ", price=" + price + ", supplier=" + supplier + "]";
	}
	
	
	
	

}
