package org.cap.model;

public class Supplier {
	
	private int supplierId;
	private String supplierName;
	private String address;
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Supplier(int supplierId, String supplierName, String address) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.address = address;
	}
	public Supplier() {
		super();
	}
	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", supplierName=" + supplierName + ", address=" + address + "]";
	}
	
	

}
