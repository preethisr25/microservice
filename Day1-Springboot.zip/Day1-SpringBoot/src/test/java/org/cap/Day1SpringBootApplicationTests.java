package org.cap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
