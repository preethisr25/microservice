package org.cap.service;

import java.util.List;

import org.cap.model.Product;
import org.springframework.data.repository.query.Param;

public interface IProductService {
	public List<Product> getAllProducts();

	public Product findProduct(Integer productId);

	public List<Product> deleteProduct(int productId);

	public List<Product> createProduct(Product product);
	public List<Product> findByProductNameAndQuantity(String productName,int quantity);
	public List<Product> capgeminiProduct(double product_price);
	public boolean updateProductDetails(double price);
	public List<Product> findByQuantity(int quantity);
	
}
