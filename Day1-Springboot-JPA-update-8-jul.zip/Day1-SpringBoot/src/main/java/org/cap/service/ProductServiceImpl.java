package org.cap.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.dao.IProductDBDao;
import org.cap.dao.ISupplierDBDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service("productDBService")
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductDBDao productDbDao;
	@Autowired
	private ISupplierDBDao supplierDBDao;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Product> getAllProducts() {
		
		return productDbDao.findAll();
	}

	@Override
	public Product findProduct(Integer productId) {
		
		return productDbDao.getOne(productId);
	}

	@Override
	public List<Product> deleteProduct(int productId) {
		productDbDao.deleteById(productId);
		return getAllProducts();
	}

	@Override
	public List<Product> createProduct(Product product) {
		supplierDBDao.save(product.getSupplier());
		productDbDao.save(product);
		return getAllProducts();
	}

	@Override
	public List<Product> findByProductNameAndQuantity(String productName, int quantity) {
		
		return productDbDao.findByProductNameAndQuantity(productName, quantity);
	}

	@Override
	public List<Product> capgeminiProduct(double product_price) {
		// TODO Auto-generated method stub
		return productDbDao.capgeminiProduct(product_price);
	}

	@Transactional
	@Override
	public boolean updateProductDetails(double price) {
		
		//JPQL Query using JPA
		Query query= entityManager.createQuery("update Product p set p.price=:newPrice where p.quantity<400");
		query.setParameter("newPrice", price);
		int count=query.executeUpdate();
				
			if(count>0)
				return true;
			else
				return false;
		//productDbDao.updateProductDetails(price);
	}

	@Transactional
	@Override
	public List<Product> findByQuantity(int quantity) {
		List<Product>  products= productDbDao.findByQuantity(quantity);
		for(Product product:products)
			product.setPrice(500.0);
		return products;
	}

}
