package org.cap.dao;

import java.util.List;

import org.cap.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("productDbDao")
@Transactional
public interface IProductDBDao extends JpaRepository<Product, Integer> {
	
	
	//public void updateProductDetails(@Param("newPrice") double price);
	
	
	public List<Product> findByQuantity(int quantity);
	
	//JPQL Query
	@Query("from Product p where p.price> :product_price")
	public List<Product> capgeminiProduct(@Param("product_price")double product_price);
	
	public List<Product> findByProductNameAndQuantity(String productName,int quantity);
	public List<Product> findByProductNameOrQuantity(String productName,int quantity);
	public List<Product> getByPrice(double price);
	
}
