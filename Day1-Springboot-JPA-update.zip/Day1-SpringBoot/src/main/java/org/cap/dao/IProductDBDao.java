package org.cap.dao;

import org.cap.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("productDbDao")
@Transactional
public interface IProductDBDao extends JpaRepository<Product, Integer> {

	
}
