package org.cap.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Product;
import org.cap.model.Supplier;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImp implements IProductDao{
	private static AtomicInteger supplierId=new AtomicInteger(1);
	private static AtomicInteger productId=new AtomicInteger(1000);
	private static List<Product> products=dummyDB();
	
	private static List<Product>  dummyDB(){
		List<Product> products=new ArrayList<>();
		Supplier tom=new Supplier(supplierId.getAndIncrement(), "Tom","Westcar street ");
		products.add(new Product(productId.getAndIncrement(), "Mobile", LocalDate.of(2023, 12, 2),100, 12000, tom));
		products.add(new Product(productId.getAndIncrement(), "Mouse", LocalDate.of(2056, 12, 2),25, 1500, tom));
		
		Supplier jerry=new Supplier(supplierId.getAndIncrement(), "Jerry","East car street ");
		products.add(new Product(productId.getAndIncrement(), "Laptop", LocalDate.of(2033, 2, 12),45, 120000, jerry));
		
		Supplier jack=new Supplier(supplierId.getAndIncrement(), "Jack","North Avvenue ");
		products.add(new Product(productId.getAndIncrement(), "Headphone", LocalDate.of(2023, 12, 2),500, 250, jack));
		
		
		return products;
	}
	
	
	@Override
	public List<Product> getAllProducts() {
		
		return products;
	}


	@Override
	public Product findProduct(Integer productId) {
		
		for(Product product:products)
		{
			if(productId==product.getProductId())
				return product;
		}
		
		return null;
	}


	@Override
	public List<Product> deleteProduct(int productId) {
		
		boolean flag=false;
		
		Iterator<Product> iterator= products.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId)
			{
				iterator.remove();
				flag=true;
				break;
			}
		}
		
		if(flag)
			return products;
		else
			return null;
	}


	@Override
	public List<Product> createProduct(Product product) {
		products.add(product);
		return products;
	}

}
 