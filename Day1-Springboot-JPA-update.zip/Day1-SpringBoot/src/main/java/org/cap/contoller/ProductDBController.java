package org.cap.contoller;

import java.util.List;

import org.cap.dao.IProductDao;
import org.cap.model.Product;
import org.cap.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2")
public class ProductDBController {

	@Autowired
	private IProductService productDBService;
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(
			@RequestBody Product product){
		List<Product> list= productDBService.createProduct(product);
		
		if(list==null || list.isEmpty())
			return new ResponseEntity("Sorry! INsertion Error!", 
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(
			@PathVariable("productId") Integer productId){
		List<Product> list= productDBService.deleteProduct(productId);
		
		if(list==null || list.isEmpty())
			return new ResponseEntity("Sorry! Deletion Error!", 
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
	}
	
	@GetMapping(value = "/products/{productId}",produces = {"application/xml"})
	public ResponseEntity<Product> findProduct(
			@PathVariable("productId")Integer productId){
		Product list= productDBService.findProduct(productId);
		
		if(list==null)
			return new ResponseEntity("Sorry! Product ID Not Available!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Product>(list, HttpStatus.OK);
	}
	
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProductList(){
		List<Product> list= productDBService.getAllProducts();
		
		if(list==null || list.isEmpty())
			return new ResponseEntity("Sorry! Product Details Not Available!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
	}
}
