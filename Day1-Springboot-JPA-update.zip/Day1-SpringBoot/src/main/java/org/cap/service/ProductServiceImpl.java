package org.cap.service;

import java.util.List;

import org.cap.dao.IProductDBDao;
import org.cap.dao.ISupplierDBDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("productDBService")
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductDBDao productDbDao;
	@Autowired
	private ISupplierDBDao supplierDBDao;
	
	@Override
	public List<Product> getAllProducts() {
		
		return productDbDao.findAll();
	}

	@Override
	public Product findProduct(Integer productId) {
		
		return productDbDao.getOne(productId);
	}

	@Override
	public List<Product> deleteProduct(int productId) {
		productDbDao.deleteById(productId);
		return getAllProducts();
	}

	@Override
	public List<Product> createProduct(Product product) {
		supplierDBDao.save(product.getSupplier());
		productDbDao.save(product);
		return getAllProducts();
	}

}
