package org.cap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestRestController {

	@RequestMapping("/greet")
	public String greetUser() {
		return "Good Morning! To All!";
	}
}
